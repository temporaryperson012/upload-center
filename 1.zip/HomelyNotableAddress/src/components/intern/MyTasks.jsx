
import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, updateDoc, addDoc } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { useAuth } from '../../contexts/AuthContext';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';

export default function MyTasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState(null);
  const [showUpdateForm, setShowUpdateForm] = useState(false);
  const { currentUser } = useAuth();
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const q = query(
        collection(db, 'tasks'),
        where('assignedTo', '==', currentUser.uid)
      );
      const querySnapshot = await getDocs(q);
      const tasksData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setTasks(tasksData.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate)));
    } catch (error) {
      console.error('Error fetching tasks:', error);
      toast.error('Failed to fetch tasks');
    } finally {
      setLoading(false);
    }
  };

  const updateTaskStatus = async (taskId, newStatus) => {
    try {
      await updateDoc(doc(db, 'tasks', taskId), {
        status: newStatus,
        updatedAt: new Date()
      });
      
      setTasks(tasks.map(task => 
        task.id === taskId ? { ...task, status: newStatus } : task
      ));
      toast.success('Task status updated');
    } catch (error) {
      console.error('Error updating task:', error);
      toast.error('Failed to update task status');
    }
  };

  const submitProgress = async (data) => {
    try {
      // Add progress update to subcollection
      await addDoc(collection(db, 'tasks', selectedTask.id, 'updates'), {
        notes: data.notes,
        blockers: data.blockers,
        progress: data.progress,
        submittedAt: new Date(),
        submittedBy: currentUser.uid
      });

      // Update task status if completed
      if (data.markAsCompleted) {
        await updateTaskStatus(selectedTask.id, 'completed');
      } else if (selectedTask.status === 'pending') {
        await updateTaskStatus(selectedTask.id, 'in-progress');
      }

      setShowUpdateForm(false);
      setSelectedTask(null);
      reset();
      toast.success('Progress updated successfully');
    } catch (error) {
      console.error('Error submitting progress:', error);
      toast.error('Failed to submit progress');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const isOverdue = (dueDate) => {
    return new Date(dueDate) < new Date() && selectedTask?.status !== 'completed';
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">My Tasks</h1>
          <p className="mt-2 text-gray-600">
            Track your assigned tasks and submit progress updates.
          </p>
        </div>

        {/* Task Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-gray-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">
                      {tasks.filter(task => task.status === 'pending').length}
                    </span>
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      Pending Tasks
                    </dt>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">
                      {tasks.filter(task => task.status === 'in-progress').length}
                    </span>
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      In Progress
                    </dt>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">
                      {tasks.filter(task => task.status === 'completed').length}
                    </span>
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      Completed
                    </dt>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tasks List */}
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {tasks.length === 0 ? (
              <li className="px-6 py-4 text-center text-gray-500">
                No tasks assigned yet. Check back later for new assignments.
              </li>
            ) : (
              tasks.map((task) => (
                <li key={task.id}>
                  <div className="px-6 py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-medium text-gray-900">{task.title}</h3>
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(task.status)}`}>
                              {task.status}
                            </span>
                            {isOverdue(task.dueDate) && (
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                Overdue
                              </span>
                            )}
                          </div>
                        </div>
                        <p className="mt-1 text-sm text-gray-600">{task.description}</p>
                        <div className="mt-2 flex items-center text-sm text-gray-500">
                          <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                          <span className="mx-2">•</span>
                          <span className={`font-medium ${getPriorityColor(task.priority)}`}>
                            {task.priority} priority
                          </span>
                        </div>
                        <div className="mt-3 flex space-x-3">
                          {task.status !== 'completed' && (
                            <>
                              <button
                                onClick={() => updateTaskStatus(task.id, 'in-progress')}
                                disabled={task.status === 'in-progress'}
                                className="text-blue-600 hover:text-blue-900 disabled:text-gray-400 text-sm font-medium"
                              >
                                {task.status === 'in-progress' ? 'In Progress' : 'Start Task'}
                              </button>
                              <button
                                onClick={() => {
                                  setSelectedTask(task);
                                  setShowUpdateForm(true);
                                }}
                                className="text-green-600 hover:text-green-900 text-sm font-medium"
                              >
                                Update Progress
                              </button>
                            </>
                          )}
                          {task.status === 'completed' && (
                            <span className="text-green-600 text-sm font-medium">✓ Completed</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>

        {/* Progress Update Modal */}
        {showUpdateForm && selectedTask && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
              <h3 className="text-lg font-bold text-gray-900 mb-4">
                Update Progress: {selectedTask.title}
              </h3>
              <form onSubmit={handleSubmit(submitProgress)} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Progress Notes</label>
                  <textarea
                    {...register("notes", { required: "Progress notes are required" })}
                    className="form-input"
                    rows="3"
                    placeholder="Describe what you've accomplished..."
                  />
                  {errors.notes && (
                    <p className="mt-1 text-sm text-red-600">{errors.notes.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Blockers (if any)</label>
                  <textarea
                    {...register("blockers")}
                    className="form-input"
                    rows="2"
                    placeholder="Any challenges or blockers you're facing..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Progress Percentage</label>
                  <select
                    {...register("progress", { required: "Progress percentage is required" })}
                    className="form-input"
                  >
                    <option value="">Select Progress</option>
                    <option value="0">0% - Not started</option>
                    <option value="25">25% - Started</option>
                    <option value="50">50% - Half done</option>
                    <option value="75">75% - Almost done</option>
                    <option value="100">100% - Completed</option>
                  </select>
                  {errors.progress && (
                    <p className="mt-1 text-sm text-red-600">{errors.progress.message}</p>
                  )}
                </div>

                <div className="flex items-center">
                  <input
                    {...register("markAsCompleted")}
                    type="checkbox"
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label className="ml-2 block text-sm text-gray-900">
                    Mark this task as completed
                  </label>
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowUpdateForm(false);
                      setSelectedTask(null);
                      reset();
                    }}
                    className="btn-secondary"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn-primary">
                    Submit Update
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
