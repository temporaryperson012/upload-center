
# Intern Management & IT Mentorship Tool

A comprehensive Firebase-powered web application for managing interns and facilitating IT mentorship programs.

## Features

### 🔐 Authentication & Roles
- Firebase Authentication with Email & Password login
- Role-based access control (Mentor/Intern)
- Secure user registration with role assignment
- Protected routes based on user roles

### 🧑‍🏫 Mentor Features
- **Intern Management**: Add, view, and remove interns
- **Task Assignment**: Create and assign tasks to interns
- **Progress Monitoring**: Track task completion and progress updates
- **Dashboard**: Overview of all interns and their performance
- **Reports & Analytics**: Visual charts and performance metrics
- **Data Export**: Export task and progress data to CSV

### 🧑‍💻 Intern Features
- **Task Management**: View assigned tasks with priorities and due dates
- **Progress Updates**: Submit detailed progress reports with notes and blockers
- **Personal Dashboard**: Overview of task completion and timeline
- **Timeline View**: Track internship duration and milestones
- **Performance Tracking**: Visual progress charts and statistics

### 📊 Analytics & Reporting
- Task status distribution charts
- Intern performance metrics
- Progress tracking over time
- Exportable reports (CSV format)
- Real-time dashboard updates

## Tech Stack

- **Frontend**: React.js with Vite
- **Styling**: Tailwind CSS
- **Backend**: Firebase (Firestore, Authentication)
- **Charts**: Recharts
- **Form Handling**: React Hook Form
- **Routing**: React Router DOM
- **Icons**: Heroicons
- **Notifications**: React Hot Toast

## Project Structure

```
src/
├── components/
│   ├── auth/
│   │   ├── Login.jsx
│   │   └── Signup.jsx
│   ├── layout/
│   │   └── Navbar.jsx
│   ├── mentor/
│   │   ├── InternManagement.jsx
│   │   ├── TaskManagement.jsx
│   │   └── Reports.jsx
│   ├── intern/
│   │   ├── MyTasks.jsx
│   │   └── Progress.jsx
│   ├── Dashboard.jsx
│   └── ProtectedRoute.jsx
├── contexts/
│   └── AuthContext.jsx
├── firebase/
│   └── config.js
├── App.jsx
├── main.jsx
└── index.css
```

## Setup Instructions

### 1. Clone the Repository
```bash
git clone <repository-url>
cd intern-management-tool
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Firebase Setup
1. Create a new Firebase project at [Firebase Console](https://console.firebase.google.com/)
2. Enable Authentication with Email/Password provider
3. Create a Firestore database
4. Copy your Firebase configuration
5. Update `src/firebase/config.js` with your Firebase credentials:

```javascript
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id"
};
```

### 4. Firestore Security Rules
Add these security rules to your Firestore database:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users collection
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      allow read: if request.auth != null && resource.data.role == 'intern' && request.auth.uid in resource.data.mentorId;
    }
    
    // Tasks collection
    match /tasks/{taskId} {
      allow read, write: if request.auth != null && 
        (resource.data.mentorId == request.auth.uid || resource.data.assignedTo == request.auth.uid);
      allow create: if request.auth != null && request.auth.uid == request.resource.data.mentorId;
    }
    
    // Task updates subcollection
    match /tasks/{taskId}/updates/{updateId} {
      allow read, write: if request.auth != null && 
        (request.auth.uid == resource.data.submittedBy || 
         request.auth.uid == get(/databases/$(database)/documents/tasks/$(taskId)).data.mentorId);
    }
  }
}
```

### 5. Run the Development Server
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

### 6. Build for Production
```bash
npm run build
```

## Firestore Data Schema

### Users Collection (`/users/{uid}`)
```javascript
{
  email: "user@example.com",
  name: "User Name",
  role: "mentor" | "intern",
  createdAt: timestamp,
  
  // Mentor specific fields
  department: "IT",
  experience: "5 years",
  
  // Intern specific fields
  university: "University Name",
  startDate: "2024-01-01",
  endDate: "2024-06-01",
  mentorId: "mentor-uid"
}
```

### Tasks Collection (`/tasks/{taskId}`)
```javascript
{
  title: "Task Title",
  description: "Task description",
  mentorId: "mentor-uid",
  assignedTo: "intern-uid",
  status: "pending" | "in-progress" | "completed",
  priority: "low" | "medium" | "high",
  dueDate: "2024-02-01",
  createdAt: timestamp,
  updatedAt: timestamp
}
```

### Task Updates Subcollection (`/tasks/{taskId}/updates/{updateId}`)
```javascript
{
  notes: "Progress notes",
  blockers: "Any blockers faced",
  progress: 75, // percentage
  submittedAt: timestamp,
  submittedBy: "intern-uid"
}
```

## Usage

### For Mentors
1. Sign up with role "Mentor"
2. Add interns to your mentorship program
3. Create and assign tasks to interns
4. Monitor progress through the dashboard
5. View detailed reports and analytics
6. Export data for external reporting

### For Interns
1. Sign up with role "Intern" 
2. View assigned tasks on your dashboard
3. Update task progress with detailed notes
4. Track your overall internship progress
5. View timeline and remaining duration

## Features in Detail

### Dashboard
- Role-specific dashboards with relevant metrics
- Quick action buttons for common tasks
- Visual progress indicators
- Timeline information for interns

### Task Management
- Create tasks with titles, descriptions, due dates, and priorities
- Assign tasks to specific interns
- Update task status (pending, in-progress, completed)
- Delete or modify existing tasks

### Progress Tracking
- Submit detailed progress updates with notes and blockers
- Visual progress percentage tracking
- Timeline view of all updates
- Automatic status updates based on progress

### Reports & Analytics
- Interactive charts showing task distribution and completion rates
- Intern performance metrics and comparisons
- Export functionality for external reporting
- Real-time data updates

## Deployment

### Replit Deployment
This application is optimized for deployment on Replit:

1. The application runs on port 5000 (configured in vite.config.js)
2. All dependencies are properly configured
3. No additional server setup required

### Firebase Hosting (Optional)
For production deployment, you can also use Firebase Hosting:

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
npm run build
firebase deploy
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Support

For support and questions, please create an issue in the repository or contact the development team.

## License

This project is licensed under the ISC License.
