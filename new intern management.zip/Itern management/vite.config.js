import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5000,
    allowedHosts: [
      "b246b36f-91d7-49a8-aacf-048c67b2fd8a-00-28ddvst7ofrgw.pike.replit.dev",
    ],
  },
});
