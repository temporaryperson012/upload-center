
import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/config';
import { 
  UserGroupIcon, 
  ClipboardListIcon, 
  ChartBarIcon, 
  ClockIcon 
} from '@heroicons/react/outline';

export default function Dashboard() {
  const { currentUser, userRole } = useAuth();
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    fetchDashboardData();
    fetchUserData();
  }, [currentUser, userRole]);

  const fetchUserData = async () => {
    if (currentUser) {
      const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
      if (userDoc.exists()) {
        setUserData(userDoc.data());
      }
    }
  };

  const fetchDashboardData = async () => {
    try {
      if (userRole === 'mentor') {
        // Fetch mentor statistics
        const internsQuery = query(
          collection(db, 'users'),
          where('role', '==', 'intern'),
          where('mentorId', '==', currentUser.uid)
        );
        const internsSnapshot = await getDocs(internsQuery);
        
        const tasksQuery = query(
          collection(db, 'tasks'),
          where('mentorId', '==', currentUser.uid)
        );
        const tasksSnapshot = await getDocs(tasksQuery);
        
        const completedTasks = tasksSnapshot.docs.filter(
          doc => doc.data().status === 'completed'
        ).length;

        setStats({
          totalInterns: internsSnapshot.size,
          totalTasks: tasksSnapshot.size,
          completedTasks,
          pendingTasks: tasksSnapshot.size - completedTasks
        });
      } else if (userRole === 'intern') {
        // Fetch intern statistics
        const tasksQuery = query(
          collection(db, 'tasks'),
          where('assignedTo', '==', currentUser.uid)
        );
        const tasksSnapshot = await getDocs(tasksQuery);
        
        const completedTasks = tasksSnapshot.docs.filter(
          doc => doc.data().status === 'completed'
        ).length;
        
        const inProgressTasks = tasksSnapshot.docs.filter(
          doc => doc.data().status === 'in-progress'
        ).length;

        setStats({
          totalTasks: tasksSnapshot.size,
          completedTasks,
          inProgressTasks,
          pendingTasks: tasksSnapshot.size - completedTasks - inProgressTasks
        });
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {userData?.name || currentUser?.email}!
          </h1>
          <p className="mt-2 text-gray-600">
            Here's what's happening with your {userRole === 'mentor' ? 'mentorship' : 'internship'} today.
          </p>
        </div>

        {userRole === 'mentor' ? (
          <MentorDashboard stats={stats} />
        ) : (
          <InternDashboard stats={stats} userData={userData} />
        )}
      </div>
    </div>
  );
}

function MentorDashboard({ stats }) {
  const dashboardCards = [
    {
      title: 'Total Interns',
      value: stats.totalInterns || 0,
      icon: UserGroupIcon,
      color: 'bg-blue-500'
    },
    {
      title: 'Total Tasks',
      value: stats.totalTasks || 0,
      icon: ClipboardListIcon,
      color: 'bg-green-500'
    },
    {
      title: 'Completed Tasks',
      value: stats.completedTasks || 0,
      icon: ChartBarIcon,
      color: 'bg-purple-500'
    },
    {
      title: 'Pending Tasks',
      value: stats.pendingTasks || 0,
      icon: ClockIcon,
      color: 'bg-yellow-500'
    }
  ];

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {dashboardCards.map((card, index) => (
          <div key={index} className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <card.icon className={`h-6 w-6 text-white`} />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      {card.title}
                    </dt>
                    <dd className="text-lg font-medium text-gray-900">
                      {card.value}
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
            <div className={`${card.color} px-5 py-3`}>
              <div className="text-sm">
                <a href="#" className="font-medium text-white hover:text-gray-200">
                  View all
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
          Quick Actions
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="btn-primary">Add New Intern</button>
          <button className="btn-primary">Create Task</button>
          <button className="btn-primary">View Reports</button>
        </div>
      </div>
    </div>
  );
}

function InternDashboard({ stats, userData }) {
  const dashboardCards = [
    {
      title: 'Total Tasks',
      value: stats.totalTasks || 0,
      icon: ClipboardListIcon,
      color: 'bg-blue-500'
    },
    {
      title: 'Completed',
      value: stats.completedTasks || 0,
      icon: ChartBarIcon,
      color: 'bg-green-500'
    },
    {
      title: 'In Progress',
      value: stats.inProgressTasks || 0,
      icon: ClockIcon,
      color: 'bg-yellow-500'
    },
    {
      title: 'Pending',
      value: stats.pendingTasks || 0,
      icon: ClockIcon,
      color: 'bg-red-500'
    }
  ];

  const calculateDaysRemaining = () => {
    if (userData?.endDate) {
      const endDate = new Date(userData.endDate);
      const today = new Date();
      const diffTime = endDate - today;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 ? diffDays : 0;
    }
    return 0;
  };

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {dashboardCards.map((card, index) => (
          <div key={index} className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <card.icon className={`h-6 w-6 text-white`} />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      {card.title}
                    </dt>
                    <dd className="text-lg font-medium text-gray-900">
                      {card.value}
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
            <div className={`${card.color} px-5 py-3`}>
              <div className="text-sm">
                <a href="#" className="font-medium text-white hover:text-gray-200">
                  View all
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Internship Timeline
          </h3>
          <div className="space-y-3">
            <div>
              <span className="text-sm text-gray-600">Start Date:</span>
              <span className="ml-2 font-medium">{userData?.startDate || 'Not set'}</span>
            </div>
            <div>
              <span className="text-sm text-gray-600">End Date:</span>
              <span className="ml-2 font-medium">{userData?.endDate || 'Not set'}</span>
            </div>
            <div>
              <span className="text-sm text-gray-600">Days Remaining:</span>
              <span className="ml-2 font-medium text-blue-600">
                {calculateDaysRemaining()} days
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Quick Actions
          </h3>
          <div className="space-y-3">
            <button className="btn-primary w-full">View My Tasks</button>
            <button className="btn-primary w-full">Update Progress</button>
            <button className="btn-secondary w-full">View Timeline</button>
          </div>
        </div>
      </div>
    </div>
  );
}
