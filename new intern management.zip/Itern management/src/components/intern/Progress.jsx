
import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { useAuth } from '../../contexts/AuthContext';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import toast from 'react-hot-toast';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28'];

export default function Progress() {
  const [tasks, setTasks] = useState([]);
  const [updates, setUpdates] = useState([]);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { currentUser } = useAuth();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch user data
      const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
      if (userDoc.exists()) {
        setUserData(userDoc.data());
      }

      // Fetch tasks
      const tasksQuery = query(
        collection(db, 'tasks'),
        where('assignedTo', '==', currentUser.uid)
      );
      const tasksSnapshot = await getDocs(tasksQuery);
      const tasksData = tasksSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      // Fetch all updates for all tasks
      const allUpdates = [];
      for (const task of tasksData) {
        const updatesQuery = query(collection(db, 'tasks', task.id, 'updates'));
        const updatesSnapshot = await getDocs(updatesQuery);
        const taskUpdates = updatesSnapshot.docs.map(doc => ({
          id: doc.id,
          taskId: task.id,
          taskTitle: task.title,
          ...doc.data()
        }));
        allUpdates.push(...taskUpdates);
      }

      setTasks(tasksData);
      setUpdates(allUpdates.sort((a, b) => b.submittedAt?.seconds - a.submittedAt?.seconds));
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to fetch progress data');
    } finally {
      setLoading(false);
    }
  };

  const getTaskStatusData = () => {
    const statusCounts = tasks.reduce((acc, task) => {
      acc[task.status] = (acc[task.status] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(statusCounts).map(([status, count]) => ({
      name: status.replace('-', ' ').toUpperCase(),
      value: count
    }));
  };

  const getProgressOverTime = () => {
    // Group updates by date and calculate average progress
    const progressByDate = updates.reduce((acc, update) => {
      const date = new Date(update.submittedAt?.seconds * 1000).toLocaleDateString();
      if (!acc[date]) {
        acc[date] = { date, progress: [], count: 0 };
      }
      acc[date].progress.push(parseInt(update.progress));
      acc[date].count++;
      return acc;
    }, {});

    return Object.values(progressByDate)
      .map(day => ({
        date: day.date,
        averageProgress: Math.round(day.progress.reduce((sum, p) => sum + p, 0) / day.count),
        updates: day.count
      }))
      .sort((a, b) => new Date(a.date) - new Date(b.date));
  };

  const calculateOverallProgress = () => {
    if (tasks.length === 0) return 0;
    const completedTasks = tasks.filter(task => task.status === 'completed').length;
    return Math.round((completedTasks / tasks.length) * 100);
  };

  const calculateDaysRemaining = () => {
    if (userData?.endDate) {
      const endDate = new Date(userData.endDate);
      const today = new Date();
      const diffTime = endDate - today;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 ? diffDays : 0;
    }
    return 0;
  };

  const getDaysElapsed = () => {
    if (userData?.startDate) {
      const startDate = new Date(userData.startDate);
      const today = new Date();
      const diffTime = today - startDate;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 ? diffDays : 0;
    }
    return 0;
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  const statusData = getTaskStatusData();
  const progressData = getProgressOverTime();
  const overallProgress = calculateOverallProgress();

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">My Progress</h1>
          <p className="mt-2 text-gray-600">
            Track your internship journey and performance metrics.
          </p>
        </div>

        {/* Progress Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">{overallProgress}%</span>
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Overall Progress</dt>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">{getDaysElapsed()}</span>
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Days Elapsed</dt>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">{calculateDaysRemaining()}</span>
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Days Remaining</dt>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">{updates.length}</span>
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Total Updates</dt>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Task Status Pie Chart */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Task Status Overview</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Progress Over Time */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Progress Over Time</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={progressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="averageProgress" stroke="#8884d8" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Updates */}
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <div className="px-4 py-5 sm:px-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Recent Progress Updates
            </h3>
          </div>
          <ul className="border-t border-gray-200 divide-y divide-gray-200">
            {updates.length === 0 ? (
              <li className="px-6 py-4 text-center text-gray-500">
                No progress updates yet. Start working on your tasks and submit updates!
              </li>
            ) : (
              updates.slice(0, 10).map((update) => (
                <li key={update.id}>
                  <div className="px-6 py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-medium text-gray-900">{update.taskTitle}</h4>
                          <div className="flex items-center space-x-2">
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                              {update.progress}% Complete
                            </span>
                            <span className="text-xs text-gray-500">
                              {new Date(update.submittedAt?.seconds * 1000).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <p className="mt-1 text-sm text-gray-600">{update.notes}</p>
                        {update.blockers && (
                          <p className="mt-1 text-sm text-red-600">
                            <strong>Blockers:</strong> {update.blockers}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
