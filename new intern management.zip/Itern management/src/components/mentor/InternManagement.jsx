
import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, deleteDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { useAuth } from '../../contexts/AuthContext';
import { TrashIcon, PencilIcon } from '@heroicons/react/outline';
import toast from 'react-hot-toast';

export default function InternManagement() {
  const [interns, setInterns] = useState([]);
  const [loading, setLoading] = useState(true);
  const { currentUser } = useAuth();

  useEffect(() => {
    fetchInterns();
  }, []);

  const fetchInterns = async () => {
    try {
      const q = query(
        collection(db, 'users'),
        where('role', '==', 'intern'),
        where('mentorId', '==', currentUser.uid)
      );
      const querySnapshot = await getDocs(q);
      const internsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setInterns(internsData);
    } catch (error) {
      console.error('Error fetching interns:', error);
      toast.error('Failed to fetch interns');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveIntern = async (internId) => {
    if (window.confirm('Are you sure you want to remove this intern?')) {
      try {
        await deleteDoc(doc(db, 'users', internId));
        setInterns(interns.filter(intern => intern.id !== internId));
        toast.success('Intern removed successfully');
      } catch (error) {
        console.error('Error removing intern:', error);
        toast.error('Failed to remove intern');
      }
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Intern Management</h1>
          <button className="btn-primary">Add New Intern</button>
        </div>

        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {interns.length === 0 ? (
              <li className="px-6 py-4 text-center text-gray-500">
                No interns found. Add some interns to get started.
              </li>
            ) : (
              interns.map((intern) => (
                <li key={intern.id}>
                  <div className="px-6 py-4 flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10">
                        <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center">
                          <span className="text-sm font-medium text-white">
                            {intern.name?.charAt(0) || intern.email.charAt(0)}
                          </span>
                        </div>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {intern.name || 'No name provided'}
                        </div>
                        <div className="text-sm text-gray-500">{intern.email}</div>
                        <div className="text-sm text-gray-500">
                          University: {intern.university || 'Not specified'}
                        </div>
                        <div className="text-sm text-gray-500">
                          Duration: {intern.startDate} to {intern.endDate}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <PencilIcon className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleRemoveIntern(intern.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <TrashIcon className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
