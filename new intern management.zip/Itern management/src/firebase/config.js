
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD3LL3n9NJMr5eZ0fGed1WmORSrWIa4WaU",
  authDomain: "internmanagement7.firebaseapp.com",
  projectId: "internmanagement7",
  storageBucket: "internmanagement7.firebasestorage.app",
  messagingSenderId: "135593806357",
  appId: "1:135593806357:web:50967841ee16809111dc1c"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Auth
export const auth = getAuth(app);

// Initialize Firestore
export const db = getFirestore(app);

export default app;
