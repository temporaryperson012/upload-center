from flask import Flask, render_template, redirect, url_for, request, jsonify, session
from supabase_client import supabase
from flask_cors import CORS
import os
import webbrowser
import threading

app = Flask(__name__, static_url_path='/static')
app.secret_key = os.environ.get("SECRET_KEY", "default-secret-key")
CORS(app)

# Auto open browser on run
def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

@app.route("/")
def home():
    return redirect(url_for("login"))

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/signup")
def signup():
    return render_template("signup.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.route("/interns")
def interns():
    return render_template("interns.html")

@app.route("/tasks")
def tasks():
    return render_template("tasks.html")

@app.route("/reports")
def reports():
    return render_template("reports.html")

@app.route("/my_tasks")
def my_tasks():
    return render_template("my_tasks.html")

@app.route("/progress")
def progress():
    return render_template("progress.html")


# ============================
# Sample Supabase interaction
# ============================

@app.route("/api/interns", methods=["GET"])
def get_all_interns():
    try:
        interns = supabase.table("interns").select("*").execute()
        return jsonify(interns.data), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/interns", methods=["POST"])
def add_intern():
    data = request.get_json()
    try:
        result = supabase.table("interns").insert(data).execute()
        return jsonify(result.data), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ============================

if __name__ == "__main__":
    threading.Timer(1.25, open_browser).start()
    app.run(debug=True)
